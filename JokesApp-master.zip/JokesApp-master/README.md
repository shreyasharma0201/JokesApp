# JokesApp
A simple CRUD Web application which allows you to enter Jokes and their answers. Built with the help of ASP.NET Core using C# language.

IDE used- Visual Studio 2019.

![jokes](https://user-images.githubusercontent.com/47186806/116759086-67edd700-aa09-11eb-8863-54e366d41a11.PNG)
